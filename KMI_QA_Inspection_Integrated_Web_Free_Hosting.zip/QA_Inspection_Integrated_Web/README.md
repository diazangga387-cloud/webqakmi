# Katsuhiro QA & Inspection Portal

Integrated prototype based on E.1–E.4 and I.1–I.4 flowcharts.

## Features
- Logo uses the supplied Quality Assurance and Inspection icon.
- Roles: ADMIN, INSPECTION, STAFF, SUPPLIER.
- Input data on every E1–E4 and I1–I4 menu.
- Automatic charts per menu from entered data.
- Print current dashboard/module using browser print.
- Export CSV per module and export all modules.
- Local browser storage for demo data.
- Responsive UI for desktop/tablet/mobile.

## Free hosting
This is a static prototype. Upload the folder containing `index.html` and `logo.png` to Netlify Drop or GitHub Pages.

## Production integration
For real multi-user use, connect authentication + database/storage (e.g. Supabase/Firebase) and configure role-based access, RLS, audit logs, notifications, Kintone and Finance integration.
